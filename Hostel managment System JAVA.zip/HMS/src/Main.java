import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

//---------------------------ADDING ROOMS TO ROOMFILE-------------------------------------
////
//        Room[]  rooms = new Room[36];
//        for (int i =0 ; i < rooms.length ; i++){
//            rooms[i] = new Room(i);
//            if (rooms[i].number == 0 || rooms[i].number % 9 ==0){
//                rooms[i].setType('O');
//            }
//            rooms[i].setsFloor();
//            rooms[i].setsSeater();
//        }
//        for (Room r : rooms){
//            FileOperations.writeroom(r);
//        }
//        ArrayList<hostelite> r = new ArrayList<hostelite>(36);


//FileOperations.readFile();
//
//ArrayList<hostelite> p = FileOperations.readAllfiles();
//for (hostelite a : p){
//    System.out.println(a.getId());
//}





//

        Login a = new Login();

//
    }
}


